package loop1Package;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginScript 
{
	private static final String CHROME_DRIVER_PATH = "D:\\Deevika\\Seleniu wedriver\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe";
    private static final String LOGIN_URL = "https://app.tryloop.ai/login/password";
    private static final String STORES_VIEW_URL = "https://app.tryloop.ai/chargebacks/stores/view";
    private static final String TRANSACTIONS_URL = "https://app.tryloop.ai/chargebacks/transactions?tab_value=overview";
    private static final String CSV_FILE_PATH = "D:\\Deevika\\Seleniu wedriver\\dataSorted.csv";
    private static final String CSV_DOWNLOADED_FILE_PATH = "C:\\Users\\a\\Downloads\\chargebacks_payouts_overview.csv";
    private static final int TIMEOUT_SECONDS = 10;
    
    /*
     * Pauses the execution for the specified duration.
     * 
     * @param milliseconds: The duration to pause the execution in milliseconds.
     */
    private static void waitFor(int milliseconds) 
    {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    /*
     * Logs in to the application using the provided credentials.
     * 
     * @param driver: The WebDriver instance used to interact with the web page.
     */
	public static void loginLoop(WebDriver driver)
	{
		driver.get(LOGIN_URL);
		// Enter the email and password
		driver.findElement(By.id(":r1:")).sendKeys("qa-engineer-assignment@test.com");
		driver.findElement(By.id(":r2:")).sendKeys("QApassword123$");
		// Check if the login button is displayed
		boolean buttonPresence = driver.findElement(By.xpath("//div//button[contains(@data-testid, 'login-button')]")).isDisplayed();
		// Click the login button if it is displayed
		if (buttonPresence)
			driver.findElement(By.xpath("//div//button[contains(@data-testid, 'login-button')]")).click();
		else
			System.out.println("Login button is not getting displayed");
		
	}
	
	/*
	 * Waits for the "Skip for now" button to be visible and clicks it.
	 * 
	 * @param driver: The WebDriver instance used to interact with the web page.
	 */
	public static void skipForNowButtonClick(WebDriver driver)
	{
		// Wait for the "Skip for now" button to be visible
		(new WebDriverWait(driver, Duration.ofSeconds(10))).until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("button.css-ic1i4k")));

		// Click the "Skip for now" button
		driver.findElement(By.cssSelector("button.css-ic1i4k")).click();
	}
	
	/*
	* Navigates to the history by store page, extracts data from all pages, and calculates the sum of each column.
	* 
	* @param driver: The WebDriver instance used to interact with the web page.
	*/
	public static void navigateToHistoryByStore(WebDriver driver)
	{
		 driver.get(STORES_VIEW_URL);
	     String current_Window = driver.getWindowHandle(); 	     
	     JavascriptExecutor js = (JavascriptExecutor) driver;
	 	
		 // Scroll vertically down by 300 pixels
		 js.executeScript("window.scrollBy(0, 300);");
		 // Find the table containing the data
	     WebElement table = driver.findElement(By.xpath("//div//table"));
	     // Wait for the table header to be visible
    	 (new WebDriverWait(driver, Duration.ofSeconds(15))).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table//tr//th[1]")));
    	 waitFor(10000);
    	 
    	 // Initialize arrays to store column sums
    	 double[] grandTotal = new double[7];
    	 double[] pageDataSum = new double[7];
    	 // Initialize all elements to zero
    	 for (int i = 0; i < pageDataSum.length; i++) {
    	     pageDataSum[i] = 0.0;
    	 }		 
    	 // Extract data from all pages
		 while (true)
	     {
	        // Extract data from current page
			 LoginScript.extractDataFromHistoryStoreTable(driver,table,pageDataSum,grandTotal);
	        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
	        
	        // Check if there is a next page
	        boolean pageFound = LoginScript.isNextPageAvailable(driver);
	        if (!pageFound) 
	        {
	            break; // Exit loop if no next page is available
	        }
	        // Click on the "Next" button to navigate to the next page
	        // Locate the element you want to scroll into view and click
	        WebElement element = driver.findElement(By.xpath("//div//button[contains(@data-testid, 'pagination-next')]"));
	        
	        Actions builder = new Actions(driver);
		    Actions seriesOfActions = builder.moveToElement(element).click();
		    seriesOfActions.perform();
	    }
		// Print column sums and check if they match the grand total
		for (int i = 0; i < pageDataSum.length; i++) 
    	{
    	     System.out.printf("Sum column[%d] : %.2f%n", i + 1, pageDataSum[i]);
    	} 
		if(Arrays.equals(pageDataSum, grandTotal))
		{
			System.out.println("Summed values are matching with grand total");
		}
		else
		{
			System.out.println("Summed values are not matching with grand total");
		}

	}
    	
	/*
	* Extracts data from the history store table and calculates the sum of each column.
	* 
	* @param driver: The WebDriver instance used to interact with the web page.
	* @param table: The WebElement representing the table containing the data.
	* @param pageDataSum: An array to store the sum of each column for all rows on the current page.
	* @param grandTotal: An array to store the grand total sum of each column, after computing all available rows.
	*/
	public static void extractDataFromHistoryStoreTable(WebDriver driver, WebElement table, double[] pageDataSum, double[] grandTotal)
	{ 
		 List<WebElement> allRows = table.findElements(By.tagName("tr"));  
    	 double[] columnSums =  new double[7];
    	 
    	 for (WebElement row : allRows)
    	 {    		  		    
    		 List<WebElement> cells = row.findElements(By.tagName("td")); 
    		 if (!cells.isEmpty())
    		 { 
	    		 for (int i = 1; i < cells.size() -1; i++)
	    		 {
	                // Get the text content of the cell
	                String cellText = cells.get(i).getText();
	                // Convert the text to numerical value and add it to the column sum
	                try 
	                {
	                    double cellValue = Double.parseDouble(cellText.replace("$", "")); 
	                    // if it is the Grand Total row
	                    if (cells.get(0).getText().equals("Grand Total"))
	                    {
	                    	// Store the grand total values in the array
	                    	grandTotal[i-1] = cellValue;
	                    }
	                    else
	                    {
	                    	// Populate sum data for cells
	                    	columnSums[i-1] += cellValue;
	                    }
	                } catch (NumberFormatException e)
	                {
	                    // Ignore non-numeric values
	                }
	    		 }
    		 }
             
          }
    	 
    	 //Add the column-wise values
    	 for (int i = 0; i < columnSums.length; i++) 
    	 {
    		 pageDataSum[i] +=columnSums[i];
    	     
    	 } 	 

	}
	 
	 /*
	 * Retrieves the value of the rowspan attribute for a given table's cell element.
	 * 
	 * @param cell: The WebElement representing the table cell.
	 * @return: The value of the rowspan attribute if present, or 1 if not.
	 */
	private static int getRowspan(WebElement cell)
	{
	    String rowspan = cell.getAttribute("rowspan");
	    return rowspan == null ? 1 : Integer.parseInt(rowspan);
	}

	 /*
	 * Checks if the next page is available by locating and verifying the "Next" button.
	 * 
	 * @param driver: The WebDriver instance controlling the browser.
	 * @return: true if the "Next" button is enabled and clickable, otherwise false.
	 */
	 private static boolean isNextPageAvailable(WebDriver driver) 
     {
        try {
            // Check if the "Next" button is enabled
            WebElement nextButton = driver.findElement(By.xpath("//div//button[contains(@data-testid, 'pagination-next')]"));
            return nextButton.isEnabled();
        } catch (Exception e) {
            // "Next" button not found or not enabled
            return false;
        }
     }    
	 
	 /*
	  * This function navigates to the transaction page, applies filters for two Locations "Artisan Alchemy" and 
	  * "Blissful Buffet" and for Marketplaces "Grubhub" and waits for loading. 
	  * @param driver: The WebDriver instance used to interact with the web browser.
	  */
	 public static void navigateTransactionPageAndApplyFilters(WebDriver driver)
	 {
		 driver.get(TRANSACTIONS_URL);
		 System.out.println(driver.getCurrentUrl());
		 // Wait for the page to load
		 waitFor(2000);
		 String current_Window = driver.getWindowHandle(); 
		 // Find all buttons within the specified drop down box class and click them
		 List<WebElement> allButtons = driver.findElements(By.xpath("//div[contains(@class,'css-1pswuk')]//button"));
		 for (WebElement button:  allButtons)
    	 {
			 // Get the name of the button
    		 String buttonName = button.getText();

    		 if (buttonName.contains("Marketplaces"))
    		 {
    			 button.click();
    			 // Wait for the page to load
    			 waitFor(2000);
    			 // Check if the clear button is displayed and click it
    			 WebElement clearButton = driver.findElement(By.xpath("//div[contains(@class, 'bbyuxu')]//button"));
    			 if (clearButton.isDisplayed())
	             {
	            	 //de-select the clear button
	                 clearButton.click();
	             }
    	         // Click the checkbox for Grubhub
    	         WebElement grubhubCheckbox = driver.findElement(By.xpath("//div[contains(@aria-label, 'Grubhub')]//input[contains(@class, 'css-1m9pwf3')]"));
    	         grubhubCheckbox.click();
    	         // Wait for the page to load
    			 waitFor(2000);
    			 WebElement applyButton = driver.findElement(By.xpath("//div//button[contains(@data-testid, 'applyBtn')]"));
    	         applyButton.click();
    		}
    		else if (buttonName.contains("Locations"))    
    		{
    			 button.click();
    			 // Wait for the page to load
    			 waitFor(1000);
    			 // Check if the clear button is displayed and click it
    			 WebElement clearButton = driver.findElement(By.xpath("//div[contains(@class, 'bbyuxu')]//button"));
	             if (clearButton.isDisplayed())
	             {
	            	 //de-select the clear button
	                 clearButton.click();
	             }
    			 boolean isArtisanSelected = false;
    			 boolean isBlissfulSelected = false;
    			 while(!isBlissfulSelected || !isArtisanSelected)
    			 {
    				 // Find all the checkboxes in the list
    				 List<WebElement> allCheckBoxes = driver.findElements(By.xpath("//div[contains(@style, 'height: 4578px; width: 100%;')]//li"));
    				 waitFor(2000);
    				// Iterate over each checkbox
    			     for (WebElement checkbox : allCheckBoxes)
    			     {
    			           // Get the text of the checkbox
    			           String checkBoxName = checkbox.getText();
    			           // Click on the checkbox if it matches the conditions
    			           if (checkBoxName.equals("Artisan Alchemy") && isArtisanSelected == false  )
    			           {
    			        	   		// select the checkbox
    			                    checkbox.click();  			                 
    			                    isArtisanSelected = true;
    			                    break;  			                  
    			            }
    			           if (checkBoxName.equals("Blissful Buffet") && isBlissfulSelected == false)
    			           {
    			        	   		// select the checkbox
			                    	checkbox.click();
			                    	isBlissfulSelected = true;
			                    	break;
    			           }
    			            
    			     }
    			 }
    			 //Click on apply filter button
    			 WebElement applyButton = driver.findElement(By.xpath("//div//button[contains(@data-testid, 'applyBtn')]"));
    	         applyButton.click();	
    		 }
    	 }
	 }
     
	 /*
	  * This function extracts transaction data from the table on the page.
	  * The extracted data is saved to a CSV file.
	  * 
	  * @param driver: The WebDriver instance controlling the browser.
	  */
	 public static void extractTransactionTable(WebDriver driver)
	 {
		 // Set up a WebDriverWait instance with a timeout duration
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(TIMEOUT_SECONDS));
		 JavascriptExecutor js = (JavascriptExecutor) driver;
	
	     // Scroll vertically down by 800 pixels
	     js.executeScript("window.scrollBy(0, 800);");
		 WebElement table = driver.findElement(By.id("view-table-id"));
		 // Wait for a short period to ensure the table is fully loaded
		 waitFor(3000);
		 // Initialize a list to store the extracted data
		 List<String[]> data = new ArrayList<>();
		 // Extract column titles and find the number of columns
		 int HcellsSize = LoginScript.extractTableCloumnTitles(table,data);
		 // Extract data from all pages
	     while (true)
	     {
	         // Extract data from current page
	    	 LoginScript.extractDataFromCurrentPage(table,data,HcellsSize);
	         // Scroll to the bottom of the page to load more data
	         js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
	         // Wait for the loading spinner to disappear, indicating that new data has been loaded	         
	         wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("loading-spinner")));
	         // Check if there is a next page
	         boolean pageFound = LoginScript.isNextPageAvailable(driver);
	         if (!pageFound) 
	         {
	             break; // Exit loop if no next page is available
	         }
	         
	         // Locate the element you want to scroll into view and click
	         WebElement element = driver.findElement(By.xpath("//div//button[contains(@data-testid, 'pagination-next')]"));
	         Actions builder = new Actions(driver);
	         // Click on the "Next" button to navigate to the next page
		     Actions seriesOfActions = builder.moveToElement(element).click();
		     seriesOfActions.perform();
	     }
	     // save data to a CSV file
	     LoginScript.saveDataToCSV(data);
	 }
	 
	 /*
	  * This function saves the provided data to a CSV file specified by the constant CSV_FILE_PATH.
	  * It sorts the data based on the first column and then writes it to the CSV file.
	  * 
	  * @param data: The list of string arrays representing the data to be saved to the CSV file.
	  */
	 private static void saveDataToCSV(List<String[]> data) 
	 {
		 String filePath = CSV_FILE_PATH;
	     try (CSVWriter writer = new CSVWriter(new FileWriter(filePath)))
	     {
	    	// Sort the data based on the first column
	    	 Collections.sort(data.subList(1, data.size()), (a, b) -> a[0].compareTo(b[0]));
	         // Write each array of strings to the CSV file
	         writer.writeAll(data);
	         System.out.println("Data has been written to " + filePath);
	     } catch (IOException e)
	     {
	         e.printStackTrace();
	     }
	}
	
	 /*
	  * This function extracts the column titles from the table's header and adds them to the provided data list.
	  * It returns the number of column titles extracted.
	  * 
	  * @param table: The WebElement representing the table from which column titles are to be extracted.
	  * @param data: The list of string arrays where the extracted column titles will be added.
	  * @return: The number of column titles extracted.
	  */
	 private static int extractTableCloumnTitles(WebElement table,List<String[]> data)
	 {
		 // Find all the heading cells in the table's header
		 List<WebElement> headingCells = table.findElements(By.tagName("thead"));   
		 // Get the first row of the header
         WebElement Hrow = headingCells.get(0);
         // Find all the cells in the header row
         List<WebElement> Hcells = Hrow.findElements(By.tagName("th"));
         // Create an array to store the column titles
         String[] hrowData = new String[Hcells.size()];
         // Iterate over the heading cells and store their text in the array
         for (int j = 0; j < Hcells.size(); j++) 
         {
             hrowData[j] = Hcells.get(j).getText();
         }
         // Add the array of column titles to the data list
         data.add(hrowData);
         // Return the number of column titles extracted
         return Hcells.size();
	 }
	
	/*
	 * This function extracts data from the current page's table and adds it to the data list.
	 * It iterates through each row and cell of the table, handling rowspan and ensuring the correct data is stored.
	 *
	 * @param table: The WebElement representing the table from which data is to be extracted.
	 * @param data: The list where the extracted data will get stored.
	 * @param HcellsSize: The size of the cells in the Title Row, used to initialize the rowData array.
	 */
	private static void extractDataFromCurrentPage(WebElement table,List<String[]> data, int HcellsSize)
	{	 
        // Find all rows in the table
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        // Array to store data for rows with rowspan
        String[] rowSpanData = null;
        
        // Iterate through each row
        for (int i = 1; i < rows.size(); i++) 
        {
	         WebElement row = rows.get(i);
	         List<WebElement> cells = row.findElements(By.tagName("td"));
	         
	         // Initialize an array to store data for each row
	         String[] rowData = new String[HcellsSize];
	         // Index to keep track of the row with rowspan
	         int spanIndex= 0;
	         // Iterate through each cell in the row
	         for (int j = 0; j < cells.size(); j++) {
	             int rowspan = getRowspan(cells.get(j));
	             // Check if the cell has rowspan
	             if (rowspan > 1) {
	                 // Store the index of the row with rowspan
	                 spanIndex = i;
	                 // Handle the first cell with rowspan
	                 if (j == 0) {
	                     // Initialize array to store data for rowspan cells
	                     rowSpanData = new String[3];
	                     // Store data for rowspan cell
	                     rowData[j] = cells.get(j).getText();
	                     rowSpanData[j] = cells.get(j).getText();
	                 } else if (j > 0 && j < 3) {
	                     // Store data for rowspan cell
	                     rowData[j] = cells.get(j).getText();
	                     rowSpanData[j] = cells.get(j).getText();
	                 }
	             } else if (cells.size() != HcellsSize) {
	                 // Handle cells in rows with rowspan
	                 if (j < 3) {
	                     // Populate data from rowspan cells
	                     rowData[j] = rowSpanData[j];
	                 }
	                 // Populate data from cells beyond rowspan
	                 rowData[j + 3] = cells.get(j).getText();
	             } else {
	                 // Populate data for normal cells
	                 rowData[j] = cells.get(j).getText();
	             }
	         }
	         // Add the rowData array to the data list
	         data.add(rowData);
        }
    }
	/*
	 * This function download csv file by clicking on Download button scrolling up the window
	 * @param driver: The WebDriver instance controlling the browser 
	 */
	public static void downloadCSVFile(WebDriver driver)
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		// Scroll vertically up by 300 pixels
	    js.executeScript("window.scrollBy(0, -300);");
	    
	    // Wait for the page to load
		waitFor(2000);
	    // Check if the download button is displayed and click it
		WebElement downloadButton = driver.findElement(By.xpath("//div[contains(@aria-label, 'Export as CSV')]//button"));
        if (downloadButton.isDisplayed())
        {
        	downloadButton.click();
        }
        // Wait for the file to download
		waitFor(3000);
	}
	
	/*
	 * This function checks the downloaded csv file whether it exists or not at the specified path
	 * @return true if the CSV file exists, false otherwise.
	 */
	public static boolean isCSVFileExists()
	{
		String filePath = CSV_DOWNLOADED_FILE_PATH;
		// Create a File object for the specified file path
		File file = new File(filePath);
		// Check if the file exists, is a file (not a directory), and has a CSV file extension	    
        boolean fileExists = file.exists() && file.isFile() && filePath.toLowerCase().endsWith(".csv");
	    if (fileExists)
	    {
	        System.out.println("CSV file exists at the specified path.");
	        return true;
	    } 
	    else 
	    {
	        System.out.println("CSV file does not exist at the specified path.");
	        return false;
	    }
        
    }
	
	/*
	 * This function counts the number of rows in a CSV file. 
	 * @param filePath The path to the CSV file.
	 * @return The number of rows in the CSV file.
	 * @throws IOException If an I/O error occurs while reading the file.
	 */
	public static int countRows(String filePath) throws IOException 
	{
        int rowCount = 0;
        // Open the CSV file for reading
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath)))
        {
        	// Read each line of the file and increment the row count
            while (reader.readLine() != null) 
            {
                rowCount++;
            }
        }
        // Return the total row count
        return rowCount;
    }
	/*
	 * This function compares the row count of two CSV files.
	 * @param CSV_FILE_PATH:   path to the first CSV file.
	 * @param CSV_DOWNLOADED_FILE_PATH : path to the second CSV file.
	 * @return True: if the row counts of the two CSV files are equal, otherwise false.
	 * @throws IOException: If an I/O error occurs while reading the CSV files.
	 */   
	public static boolean compareCSVFileWithRowCount(String CSV_FILE_PATH, String CSV_DOWNLOADED_FILE_PATH) throws IOException
	{
		// Get the row count of the first CSV file
		int rowCountFile1 = countRows(CSV_FILE_PATH);
		// Get the row count of the second CSV file
		int rowCountFile2 = countRows(CSV_DOWNLOADED_FILE_PATH);
		// Compare the row counts of the two CSV files
		if (rowCountFile1 == rowCountFile2)
			return true;
		else
			return false;
		
	}
	
	/*
	 * Compares the data of two CSV files line by line.
	 * @param CSV_FILE_PATH : path to the first CSV file.
	 * @param CSV_DOWNLOADED_FILE_PATH: path to the second CSV file.
	 * @return True :if the data in both CSV files are identical, otherwise false.
	 * @throws IOException If an I/O error occurs while reading the CSV files.
	 */
	public static boolean compareCSVFilesData(String CSV_FILE_PATH, String CSV_DOWNLOADED_FILE_PATH) throws IOException
	{
		 // Create CSV readers for both files
        try (CSVReader reader1 = new CSVReader(new FileReader(CSV_FILE_PATH));
             CSVReader reader2 = new CSVReader(new FileReader(CSV_DOWNLOADED_FILE_PATH))) 
        {
            
            String[] nextLine1, nextLine2 = null;
            nextLine1 = reader1.readNext();
            nextLine2 = reader2.readNext();
            
            // Read and compare each row
            while (nextLine1 != null && nextLine2 != null)
            {
                // Convert arrays to strings for comparison
                String line1 = Arrays.toString(nextLine1);
                String line2 = Arrays.toString(nextLine2);
                
                // Compare rows
                if (!line1.equals(line2)) {
                    return false; // Files are different
                }
            }                    
            // Files are identical
            return true;
        } catch (CsvValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	/*
	 * The main method of the program.
	 * 
	 * @param args Command-line arguments.
	 */
	public static void main(String[] args) throws IOException {
	    // Set the system property for the Chrome driver
	    System.setProperty("webdriver.chrome.driver", CHROME_DRIVER_PATH);

	    // Initialize the WebDriver
	    WebDriver driver = new ChromeDriver();

	    // Maximize the browser window
	    driver.manage().window().maximize();

	    // Set implicit wait timeout for the WebDriver
	    driver.manage().timeouts().implicitlyWait(TIMEOUT_SECONDS, TimeUnit.SECONDS);

	    // Perform login process
	    LoginScript.loginLoop(driver);

	    // Click the "Skip For Now" button
	    LoginScript.skipForNowButtonClick(driver);

	    // Navigate to the history by store page and summed the values column wise
	    LoginScript.navigateToHistoryByStore(driver);

	    // Navigate to the transaction page and apply filters
	    LoginScript.navigateTransactionPageAndApplyFilters(driver);

	    // Extract transaction table data
	    LoginScript.extractTransactionTable(driver);
	    
	    //Bonus task
	    LoginScript.downloadCSVFile(driver);
	    
	    //Check CSV downloaded file exists on the path
	    boolean fileExists = LoginScript.isCSVFileExists();
	    if (fileExists)
	    {
	    	// compare files with number of rows
	    	boolean rowCountEqual = LoginScript.compareCSVFileWithRowCount(CSV_FILE_PATH, CSV_DOWNLOADED_FILE_PATH);
	    	if (rowCountEqual)
	    	{
	    		// compare files data
	    		boolean isCSVDataIdentical = LoginScript.compareCSVFilesData(CSV_FILE_PATH, CSV_DOWNLOADED_FILE_PATH);
	    		if(isCSVDataIdentical)
	    		{
	    			System.out.println("Files are identical");
	    		}
	    		else
		    	{
		    		System.out.println("Files data are not identical");
		    	}
	    	}
	    	else
	    	{
	    		System.out.println("Files are not identical");
	    	}
	    }
	    else
	    {
	    	System.out.println("CSV file coudn't get downloaded");
	    }

	    
	    // Close the WebDriver session
	    driver.quit();
	}

}

