package loop1Package;

import com.opencsv.CSVWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginScript 
{
	private static final String CHROME_DRIVER_PATH = "D:\\Deevika\\Seleniu wedriver\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe";
    private static final String LOGIN_URL = "https://app.tryloop.ai/login/password";
    private static final String STORES_VIEW_URL = "https://app.tryloop.ai/chargebacks/stores/view";
    private static final String TRANSACTIONS_URL = "https://app.tryloop.ai/chargebacks/transactions";
    private static final String CSV_FILE_PATH = "D:\\Deevika\\Seleniu wedriver\\dataSorted.csv";
    private static final int TIMEOUT_SECONDS = 10;
    
    private static void waitFor(int milliseconds) 
    {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
	public static void loginLoop(WebDriver driver)
	{
		driver.get(LOGIN_URL);
		driver.findElement(By.id(":r1:")).sendKeys("qa-engineer-assignment@test.com");
		driver.findElement(By.id(":r2:")).sendKeys("QApassword123$");
		
		boolean buttonPresence = driver.findElement(By.xpath("//div//button[contains(@data-testid, 'login-button')]")).isDisplayed();
		
		if (buttonPresence)
			driver.findElement(By.xpath("//div//button[contains(@data-testid, 'login-button')]")).click();
		else
			System.out.println("Login button is not getting displayed");
		
	}
	public static void skipForNowButtonClick(WebDriver driver)
	{
		(new WebDriverWait(driver, Duration.ofSeconds(10))).until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("button.css-ic1i4k")));
		String current_Window = driver.getWindowHandle(); 
		driver.findElement(By.cssSelector("button.css-ic1i4k")).click();
	}
	public static void navigateToHistoryByStore(WebDriver driver)
	{
		 driver.get(STORES_VIEW_URL);
	     String current_Window = driver.getWindowHandle(); 
	     
	     JavascriptExecutor js = (JavascriptExecutor) driver;
	 	
		 // Scroll vertically down by 300 pixels
		 js.executeScript("window.scrollBy(0, 300);");
	     WebElement table = driver.findElement(By.xpath("//div//table"));
    	 (new WebDriverWait(driver, Duration.ofSeconds(15))).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table//tr//th[1]")));
    	 waitFor(10000);
    	 double[] grandTotal = new double[7];
    	 double[] pageDataSum = new double[7];
    	// Initialize all elements to zero
    	 for (int i = 0; i < pageDataSum.length; i++) {
    	     pageDataSum[i] = 0.0;
    	 }
		 
    	 // Extract data from all pages
		 while (true)
	     {
	        // Extract data from current page
			extractDataFromHistoryStoreTable(driver,table,pageDataSum,grandTotal);
	        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
	        
	        // Check if there is a next page
	        boolean pageFound = isNextPageAvailable(driver);
	        if (!pageFound) 
	        {
	            break; // Exit loop if no next page is available
	        }
	        // Click on the "Next" button to navigate to the next page
	        // Locate the element you want to scroll into view and click
	        WebElement element = driver.findElement(By.xpath("//div//button[contains(@data-testid, 'pagination-next')]"));
	        
	        Actions builder = new Actions(driver);
		    Actions seriesOfActions = builder.moveToElement(element).click();
		    seriesOfActions.perform();
	    }
		for (int i = 0; i < pageDataSum.length; i++) 
    	{
    	     System.out.printf("Sum column[%d] : %.2f%n", i + 1, pageDataSum[i]);
    	} 
		if(Arrays.equals(pageDataSum, grandTotal))
		{
			System.out.println("Summed values are matching with grand total");
		}
		else
		{
			System.out.println("Summed values are not matching with grand total");
		}

	}
    	
	public static void extractDataFromHistoryStoreTable(WebDriver driver, WebElement table, double[] pageDataSum, double[] grandTotal)
	{ 
		 List<WebElement> allRows = table.findElements(By.tagName("tr"));  
    	 double[] columnSums =  new double[7];
    	 
    	 for (WebElement row : allRows)
    	 {    		  		    
    		 List<WebElement> cells = row.findElements(By.tagName("td")); 
    		 if (!cells.isEmpty())
    		 { 
	    		 for (int i = 1; i < cells.size() -1; i++)
	    		 {
	                // Get the text content of the cell
	                String cellText = cells.get(i).getText();
	                // Convert the text to numerical value and add it to the column sum
	                try 
	                {
	                    double cellValue = Double.parseDouble(cellText.replace("$", "")); 
	                    if (cells.get(0).getText().equals("Grand Total"))
	                    {
	                    	grandTotal[i-1] = cellValue;
	                    }
	                    else
	                    {
	                    	columnSums[i-1] += cellValue;
	                    }
	                } catch (NumberFormatException e)
	                {
	                    // Ignore non-numeric values
	                }
	    		 }
    		 }
             
          }
    	 
    	 //Add the column-wise values
    	 for (int i = 0; i < columnSums.length; i++) 
    	 {
    		 pageDataSum[i] +=columnSums[i];
    	     
    	 } 	 

	}
	 
	private static int getRowspan(WebElement cell)
	{
	    String rowspan = cell.getAttribute("rowspan");
	    return rowspan == null ? 1 : Integer.parseInt(rowspan);
	}

	 private static boolean isNextPageAvailable(WebDriver driver) 
    {
        try {
            // Check if the "Next" button is enabled
            WebElement nextButton = driver.findElement(By.xpath("//div//button[contains(@data-testid, 'pagination-next')]"));
            boolean btnEnabled = nextButton.isEnabled();
            return btnEnabled;
        } catch (Exception e) {
            // "Next" button not found or not enabled
            return false;
        }
    }    
 	
	 public static void navigateTransactionPageAndApplyFilters(WebDriver driver)
	 {
		 driver.get(TRANSACTIONS_URL);
		 String current_Window = driver.getWindowHandle(); 
		 List<WebElement> allButtons = driver.findElements(By.xpath("//div[contains(@class,'css-1pswuk')]//button"));
		 for (WebElement button:  allButtons)
    	 {
    		 String buttonName = button.getText();

    		if (buttonName.contains("Marketplaces"))
    		{
    			 button.click();
    			 waitFor(2000);
    			 WebElement clearButton = driver.findElement(By.xpath("//div[contains(@class, 'bbyuxu')]//button"));
    	         if (clearButton.isDisplayed()) 
    	         {
    	              clearButton.click();
    	         }

    	         WebElement grubhubCheckbox = driver.findElement(By.xpath("//div[contains(@aria-label, 'Grubhub')]//input[contains(@class, 'css-1m9pwf3')]"));
    	         grubhubCheckbox.click();

    			 waitFor(2000);
    			 WebElement applyButton = driver.findElement(By.xpath("//div//button[contains(@data-testid, 'applyBtn')]"));
    	         applyButton.click();
    		}
    		else if (buttonName.contains("Locations"))    
    		{
    			 button.click();
    			 waitFor(1000);
    			 WebElement clearButton = driver.findElement(By.xpath("//div[contains(@class, 'bbyuxu')]//button"));
	            if (clearButton.isDisplayed()) {
	                clearButton.click();
	            }
    			 boolean isArtisanSelected = false;
    			 boolean isBlissfulSelected = false;
    			 while(!isBlissfulSelected || !isArtisanSelected)
    			 {
    				 List<WebElement> allCheckBoxes = driver.findElements(By.xpath("//div[contains(@style, 'height: 4578px; width: 100%;')]//li"));
    				 waitFor(2000);
    				// Iterate over each checkbox
    			     for (WebElement checkbox : allCheckBoxes)
    			     {
    			           // Get the text of the checkbox
    			           String checkBoxName = checkbox.getText();
    			           // Click on the checkbox if it matches the conditions
    			           if (checkBoxName.equals("Artisan Alchemy") && isArtisanSelected == false  )
    			           {
    			                    checkbox.click();  			                 
    			                    isArtisanSelected = true;
    			                    break;  			                  
    			            }
    			           if (checkBoxName.equals("Blissful Buffet") && isBlissfulSelected == false)
    			           {
			                    	checkbox.click();
			                    	isBlissfulSelected = true;
			                    	break;
    			           }
    			            
    			     }
    			 }
    			 //Click on apply filter button
    			 WebElement applyButton = driver.findElement(By.xpath("//div//button[contains(@data-testid, 'applyBtn')]"));
    	         applyButton.click();	
    		 }
    	 }
	 }
     
    
	 public static void extractTransactionTable(WebDriver driver)
	 {
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(TIMEOUT_SECONDS));
		 JavascriptExecutor js = (JavascriptExecutor) driver;
	
	     // Scroll vertically down by 500 pixels
	     js.executeScript("window.scrollBy(0, 800);");
		 WebElement table = driver.findElement(By.id("view-table-id"));
		 waitFor(3000);
		 List<String[]> data = new ArrayList<>();
		 int HcellsSize = extractTableCloumnTitles(table,data);
		// Extract data from all pages
	     while (true)
	     {
	         // Extract data from current page
	         extractDataFromCurrentPage(table,data,HcellsSize);
	         js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
	         wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("loading-spinner")));
	         // Check if there is a next page
	         boolean pageFound = isNextPageAvailable(driver);
	         if (!pageFound) 
	         {
	             break; // Exit loop if no next page is available
	         }
	         // Click on the "Next" button to navigate to the next page
	         // Locate the element you want to scroll into view and click
	         WebElement element = driver.findElement(By.xpath("//div//button[contains(@data-testid, 'pagination-next')]"));
	         Actions builder = new Actions(driver);
		     Actions seriesOfActions = builder.moveToElement(element).click();
		     seriesOfActions.perform();
	     }
	
	    saveDataToCSV(data);
	 }
	 private static void saveDataToCSV(List<String[]> data) 
	 {
		 String filePath = CSV_FILE_PATH;
	     try (CSVWriter writer = new CSVWriter(new FileWriter(filePath)))
	     {
	    	 //Sort the data 
	    	 Collections.sort(data.subList(1, data.size()), (a, b) -> a[0].compareTo(b[0]));
	         // Write each array of strings to the CSV file
	         writer.writeAll(data);
	         System.out.println("Data has been written to " + filePath);
	     } catch (IOException e)
	     {
	         e.printStackTrace();
	     }
	}
	
	private static int extractTableCloumnTitles(WebElement table,List<String[]> data)
	{
		 List<WebElement> headingCells = table.findElements(By.tagName("thead"));     	 
         WebElement Hrow = headingCells.get(0);
         List<WebElement> Hcells = Hrow.findElements(By.tagName("th"));
         String[] hrowData = new String[Hcells.size()];
         for (int j = 0; j < Hcells.size(); j++)
         {
             hrowData[j] = Hcells.get(j).getText();
         }
         data.add(hrowData);
         return Hcells.size();
	}
	private static void extractDataFromCurrentPage(WebElement table,List<String[]> data, int HcellsSize)
	{	 
        // Find all rows in the table
        List<WebElement> rows = table.findElements(By.tagName("tr"));
        String[] rowSpanData = null;
        for (int i = 1; i < rows.size(); i++) 
        {
	         WebElement row = rows.get(i);
	         List<WebElement> cells = row.findElements(By.tagName("td"));
	         String[] rowData = new String[HcellsSize];
	         int spanIndex= 0;
	         for (int j = 0; j < cells.size(); j++)
	         {
	             int rowspan = getRowspan(cells.get(j));
	             if(rowspan>1)
	             {
	            	 spanIndex = i;
	            	 if (j ==0)
	            	 {
	            		 rowSpanData = new String[3];
	            		 rowData[j] = cells.get(j).getText();
		        		 rowSpanData[j] = cells.get(j).getText(); 
	            	 }
	            	 else if (j >0 && j<3)
		        	 {
		        		 rowData[j] = cells.get(j).getText();
		        		 rowSpanData[j] = cells.get(j).getText();   
		        	 }
	             }
	        	 else if(cells.size() != HcellsSize)
	        	 {
	        		 if (j<3)
	        		 {
	        			 rowData[j]= rowSpanData[j];	        		
	        		 }
	        		 rowData[j+3] = cells.get(j).getText();	        			 
	        	 }
	        	 else
	        	 {
	        		 rowData[j] = cells.get(j).getText();
	        	 }
	         }      
	         data.add(rowData);
        }
    }
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver",
				CHROME_DRIVER_PATH);
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(TIMEOUT_SECONDS, TimeUnit.SECONDS);
		loginLoop(driver);
		skipForNowButtonClick(driver);
		//navigateToHistoryByStore(driver);
		navigateTransactionPageAndApplyFilters(driver);
		extractTransactionTable(driver);

		
		   
		
				
		//driver.quit();
	}

	
   

}

